<?php get_header();?>

<!-- Slider -->
 <div class="container-fluid ATF">

  <!--Carousel Wrapper-->
  <div id="carousel" class="carousel slide" data-ride="carousel">
      <!--Indicators-->
      <ol class="carousel-indicators">
          <li data-target="#carousel" data-slide-to="0" class="active"></li>
          <li data-target="#carousel" data-slide-to="1" class=""></li>
          <li data-target="#carousel" data-slide-to="2" class=""></li>
      </ol>
      <!--/.Indicators-->

      <!--Slides-->
      <div class="carousel-inner" role="listbox">

          <!--First slide-->
          <div class="carousel-item active">
            
              <div class="firstslide">
                   <div class="flexbox">
                    <div class="container">
                       <h1>Let's Make Your<br>Best Trip Ever</h1>
                       <div class="spacer"></div>
                        <h2>We are commited to offering travel services of the highest quality, combining our energy and enthusiasm, with our years of experience.</h2>
                        <div class="spacer"></div>
                        <a href="#" class="btn btn-custom"><i class="fa fa-paper-plane-o"></i> &nbsp;BOOK A TOUR</a>
                    </div>
                    </div>                     
                </div>
          </div>
          <!--/.First slide-->

          <!--Second slide-->
          <div class="carousel-item">

              <div class="secondslide">
                   <div class="flexbox">
                    <div class="container">
                       <h1>Let's Make Your<br>Best Trip Ever</h1>
                       <div class="spacer"></div>
                        <h2>We are commited to offering travel services of the highest quality, combining our energy and enthusiasm, with our years of experience.</h2>
                        <div class="spacer"></div>
                        <a href="#" class="btn btn-custom"><i class="fa fa-paper-plane-o"></i> &nbsp;BOOK A TOUR</a>
                    </div>
                    </div>                     
                </div>  

          </div>
          <!--/.Second slide-->

          <!--Third slide-->
          <div class="carousel-item">

              <div class="thirdslide">
                   <div class="flexbox">
                    <div class="container">
                       <h1>Let's Make Your<br>Best Trip Ever</h1>
                       <div class="spacer"></div>
                        <h2>We are commited to offering travel services of the highest quality, combining our energy and enthusiasm, with our years of experience.</h2>
                        <div class="spacer"></div>
                        <a href="#" class="btn btn-custom"><i class="fa fa-paper-plane-o"></i> &nbsp;BOOK A TOUR</a>
                    </div>
                    </div>                     
                </div> 
                
          </div>
          <!--/.Third slide-->

      </div>
      <!--/.Slides-->

      <!--Controls-->
      <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
      </a>
      <!--/.Controls-->
  </div>
  <!--/.Carousel Wrapper-->

</div>

    <!-- End Slider -->

    <!-- Featured Tours Section -->
      <section id="Featured-tours">
      <div class="container" id="toursFeatured">
      <div class="col-lg-12">
          <h1 class="tours">Featured Tours</h1> 
          <p id="feature">Explore the world with Intense! We offer you a vast variety of tours of all types featuring both exotic and already well-known destinations, some of which are listed below.</p>
      </div>
      <div class="row" id="tours">
        <div class="col-lg-3 mb-3">
           <p><img src="images/tours1.jpg" height="330" width="247"></p>
                <h5>Kamalame Cay Resort</h5>
                <p>Kamalame Cay, The Bahamas</p>
              <center><a href="#" class="btn"><i class="fa fa-paper-plane-o"></i> &nbsp;READ MORE</a></center>
        </div>
        <div class="col-lg-3 mb-3">
           <p><img src="images/tours2.jpg" height="330" width="247"></p>
                <h5>Kamalame Cay Resort</h5>
                <p>Kamalame Cay, The Bahamas</p>
              <center><a href="#" class="btn"><i class="fa fa-paper-plane-o"></i> &nbsp;READ MORE</a></center>
        </div>
        <div class="col-lg-3 mb-3">
           <p><img src="images/tours3.jpg" height="330" width="247"></p>
                <h5>Kamalame Cay Resort</h5>
                <p>Kamalame Cay, The Bahamas</p>
              <center><a href="#" class="btn"><i class="fa fa-paper-plane-o"></i> &nbsp;READ MORE</a></center>
        </div>
        <div class="col-lg-3 mb-3">
           <p><img src="images/tours4.jpg" height="330" width="247"></p>
                <h5>Kamalame Cay Resort</h5>
                <p>Kamalame Cay, The Bahamas</p>
              <center><a href="#" class="btn"><i class="fa fa-paper-plane-o"></i> &nbsp;READ MORE</a></center>
        </div>
    </div>
  </div>
</section>
   <!-- End Featured Tours Section -->

    <!-- Best Tours Section -->
      <section id="Best-tours">
      <div class="container-fluid" id="bestTours">
        <div class="col-lg-12">
          <h1>We Provide Only the Best Tours</h1> 
           <p>With more than 230 trips to worldwide destinations, including Europe, North & Central, South America, Asia, Australia & New Zealand, we continue to offer new ways and the best tours for traveling every year.</p>
           <div class="spacer"></div>
          <center><a href="#" class="btn-white "><i class="fa fa-paper-plane-o"></i> &nbsp;READ MORE</a></center> 
    </div>
  </div>
</section>
   <!-- End Best Tours Section -->

  <!-- Why Us Section -->
      <section id="why-us">
      <div class="container" id="whyUs">
      <div class="col-lg-12">
          <h1 class="tours">Why Us</h1> 
      </div>
      <div class="spacer"></div>
      <div class="row">
        <div class="col-lg-4 mb-4">
           <p><img src="images/whyus-icon01.png" height="100" width="81"></p>
                <h5>The Best Service</h5>
                <p>Our aim is to provide you with the tour service of the top quality, and we'll do our best to find the suitable tour for you.</p>
        </div>
        <div class="col-lg-4 mb-4">
           <p><img src="images/whyus-icon02.png" height="100" width="81"></p>
                <h5>Everything Is Included</h5>
                <p>There are dozens of aspects to pay attention to, while organizing a trip, and we’ll make sure your tour includes everything you need.</p>
        </div>
        <div class="col-lg-4 mb-4">
           <p><img src="images/whyus-icon03.png" height="100" width="81"></p>
                <h5>Great Prices</h5>
                <p>All our tours and excursions are available at really affordable prices so you can always pick a great destination.</p>
        </div>
    </div>
  </div>
</section>
   <!-- Why Us Section -->
   
     <!-- Our Partner Section -->
      <section id="our-partner">
      <div class="container" id="ourPartner">
      <div class="col-lg-12">
          <h1 class="tours">Our Partners</h1> 
      </div>
      <div class="spacer"></div>
      <div class="row">
        <div class="col-lg-2 mb-2">
           <p><img src="images/partner01.png" height="70" width="160"></p>
        </div>
        <div class="col-lg-2 mb-2">
           <p><img src="images/partner02.png" height="70" width="160"></p>
        </div>
        <div class="col-lg-2 mb-2">
           <p><img src="images/partner03.png" height="70" width="160"></p>
        </div>
        <div class="col-lg-2 mb-2">
           <p><img src="images/partner04.png" height="70" width="160"></p>
        </div>
        <div class="col-lg-2 mb-2">
           <p><img src="images/partner05.png" height="70" width="160"></p>
        </div>
        <div class="col-lg-2 mb-2">
           <p><img src="images/partner06.png" height="70" width="160"></p>
        </div>
    </div>
    <div class="spacer"></div>
  </div>
</section>
   <!-- Our Partner Section -->  
  
    <!-- Reviews Section -->
      <section id="reviews">
      <div class="container" id="reviews-clients">
      <div class="col-lg-12">
          <h1 class="tours">What Our Clients Say</h1> 
      </div>
      <div class="spacer"></div>
      <div class="row">
        <div class="col-lg-4 mb-4">
           <div class="reviews-img">
              <p>
                <img src="images/client01.png" alt="">
              </p>
            </div>
          <div class="desc-details">
             <p>Disney in December was absolutely delightful! From our 1 day at Magic Kingdom &amp; 2 days at Animal Kingdom, our family was filled with excitement and magical memories.</p>
              <h4 class="author">- Lisa Evants</h4>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="reviews-img">
              <p>
                <img src="images/client02.png" alt="">
              </p>
            </div>
          <div class="desc-details">
             <p>You were an excellent Travel Agency for us! You considered our unique needs while planning our itinerary. Every suggestion you made was excellent!</p>
              <h4 class="author">- Nicholas Lane</h4>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="reviews-img">
              <p>
                <img src="images/client03.png" alt="">
              </p>
            </div>
          <div class="desc-details">
             <p>I’m sending you a sincere "thank you" for all of your assistance during my recent trip to Colorado. It was invaluable to me and I realize and appreciate it greatly.</p>
              <h4 class="author">- Ethan Dean</h4>
          </div>
        </div>
    </div>
      <div class="col-lg-12">
           <center><a href="#" class="btn"><i class="fa fa-paper-plane-o"></i> &nbsp;GET IN TOUCH</a></center>
      </div>
  </div>
</section>
   <!-- End of Reviews Section -->

<?php get_footer();?>
