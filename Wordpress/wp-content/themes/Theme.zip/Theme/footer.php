   <!-- Footer -->
    <div class="footer">
    <div class="container">
        <div class="row">
           <div class="col-sm-8">
            <div class="footer-logo left">
            <a href="#"><img src="images/logo.png" alt=""></a>
            </div>
            </div>
            <div class="col-sm-4">
                 <div class="social-icons">
                   <ul>
                    <li><a href="#" class="fa fa-facebook"></a></li>
                      <li><a href="#" class="fa fa-twitter"></a></li>
                     <li><a href="#" class="fa fa-google-plus"></a></li>
                      <li><a href="#" class="fa fa-linkedin"></a></li>
                    </ul>
                  </div>
            </div>
        </div>
    </div>
</div>
    <!-- End of Footer -->

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>